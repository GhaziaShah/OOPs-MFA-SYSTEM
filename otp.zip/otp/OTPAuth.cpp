#include "OTPAuth.h"
//#include "../../curl-8.13.0/builds/libcurl-vc17-x64-debug-static-ipv6-sspi-schannel/include/curl/curl.h"


    string OTPAuth::generateOTP() {
        return to_string(rand() % 900000 + 100000); // Random number in 100000-999999 range
    }

    // Callback function for libcurl to read email payload data
    size_t OTPAuth::payload_source(void* ptr, size_t size, size_t nmemb, void* userp) { 
        string* data = (string*)userp;
        if (size * nmemb < 1) return 0;
        if (data->empty()) return 0;

        // Copy payload data to libcurl's buffer
        size_t len = data->copy((char*)ptr, size * nmemb);
        data->erase(0, len);
        return len;
    }

    // Sends OTP email via SMTP using Gmail's server
    bool OTPAuth::sendOTPEmail(const string& email, const string& otp) {
        CURL* curl;
        CURLcode res = CURLE_OK;
        bool success = false;

        //Constructing email components
        string from = "ghaziabatool260@gmail.com";
        string to = email;
        string payload_text = "To: " + to + "\r\n" +
            "From: " + from + "\r\n" +
            "Subject: Your OTP Code\r\n\r\n" +
            "Your OTP is: " + otp + "\r\n" +
            "This code will expire in 5 minutes.\r\n";

        curl = curl_easy_init();
        if (curl) {
            curl_easy_setopt(curl, CURLOPT_USERNAME, "ghaziabatool260@gmail.com");
            curl_easy_setopt(curl, CURLOPT_PASSWORD, "pdrswcpmscctyvgt");
            curl_easy_setopt(curl, CURLOPT_URL, "smtps://smtp.gmail.com:465");
            curl_easy_setopt(curl, CURLOPT_USE_SSL, CURLUSESSL_ALL);
            curl_easy_setopt(curl, CURLOPT_MAIL_FROM, from.c_str());

            struct curl_slist* recipients = NULL;
            recipients = curl_slist_append(recipients, to.c_str());
            curl_easy_setopt(curl, CURLOPT_MAIL_RCPT, recipients);

            curl_easy_setopt(curl, CURLOPT_READFUNCTION, payload_source);
            curl_easy_setopt(curl, CURLOPT_READDATA, &payload_text);
            curl_easy_setopt(curl, CURLOPT_UPLOAD, 1L);
            curl_easy_setopt(curl, CURLOPT_VERBOSE, 1L);

            res = curl_easy_perform(curl);
            if (res != CURLE_OK) {
                cerr << "curl_easy_perform() failed: " << curl_easy_strerror(res) << endl;
            }
            else {
                success = true;
            }

            curl_slist_free_all(recipients);
            curl_easy_cleanup(curl);
        }
        return success;
    }

    bool OTPAuth::authenticate (const string& email, FileManager& fm){
        string otp = generateOTP();
        time_t now = time(nullptr);
        otpStorage[email] = make_pair(otp, now);

        if (!sendOTPEmail(email, otp)) {
            cerr << "Failed to send OTP email" << endl;
            return false;
        }

        cout << "OTP sent to your email. Enter OTP: ";
        string userOTP;
        cin >> userOTP;

        // Searches for the OTP associated with the given email in otptStorage
        auto it = otpStorage.find(email);
        // Checks whether the email exists in the OTP storage.
        if (it != otpStorage.end()) {
            if (difftime(time(nullptr), it->second.second) > 300) { // 5 minutes expiration
                cout << "OTP expired" << endl;
                return false;
            }
            //Compares the user entered OTP with the stored OTP.
            return userOTP == it->second.first;
        }
        return false;
    }