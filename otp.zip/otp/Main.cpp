#include <ctime>
#include "UserRegistration.h"
#include "Utilities.h"


int main() {
    srand(static_cast<unsigned int>(time(nullptr))); // Seed the random number generator with current time
    UserRegistration user ;
    int choice;

    system("cls");
    Utilities::printHeader();

    do {
        Utilities::printMenu();

        cin >> choice;

        system("cls");
        Utilities::printHeader();

        switch (choice) {
        case 1:
            user.registerUser();
            break;
        case 2:
            if (user.loginWithFallback()) {
                Utilities::printSuccess("Access granted! Welcome back!");
            }
            else {
                Utilities::printError("Access denied! All authentication methods failed");
            }
            break;
        case 3:
            user.resetPasswordWithToken();
            break;
        case 4:
            cout << "\nThank you for using our system. Goodbye!\n";
            break;
        default:
            Utilities::printError("Invalid choice. Please try again.");
        }

        if (choice != 4) {
            cout << "\nPress Enter to continue...";
            cin.ignore();
            cin.get();
            system("cls");
            Utilities::printHeader();
        }
    } while (choice != 4);

    return 0;
}