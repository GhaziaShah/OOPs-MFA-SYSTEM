
#include "FileManager.h"
#include <iostream>

using namespace std;

FileManager::FileManager() {}

vector<string> FileManager::split(const string& s, char delim) {
    vector<string> result;
    stringstream ss(s);
    string item;
    while (getline(ss, item, delim)) {
        result.push_back(item);
    }
    return result;
}

string FileManager::escapeCsvField(const string& field) {
    if (field.find('"') != string::npos || field.find(',') != string::npos) {
        return "\"" + field + "\"";
    }
    return field;
}

bool FileManager::verifyToken(const string& token) {
    ifstream file(tokenFile);
    string line;
    time_t now = time(nullptr);

    while (getline(file, line)) {
        vector<string> parts = split(line, '|');
        if (parts.size() >= 4 && parts[1] == token && stol(parts[2]) > now && parts[3] == "0") {
            return true;
        }
    }
    return false;
}

string FileManager::getEmailForToken(const string& token) {
    ifstream file(tokenFile);
    string line;
    time_t now = time(nullptr);

    while (getline(file, line)) {
        vector<string> parts = split(line, '|');
        if (parts.size() >= 4 && parts[1] == token && stol(parts[2]) > now && parts[3] == "0") {
            return parts[0];
        }
    }
    return "";
}

void FileManager::removeToken(const string& token) {
    ifstream inFile(tokenFile);
    vector<string> lines;
    string line;

    while (getline(inFile, line)) {
        vector<string> parts = split(line, '|');
        if (parts.size() >= 4 && parts[1] != token) {
            lines.push_back(line);
        }
    }
    inFile.close();

    ofstream outFile(tokenFile);
    for (const auto& l : lines) {
        outFile << l << "\n";
    }
}

bool FileManager::isEmailRegistered(const string& email) {
    ifstream file(userFile);
    string line;
    getline(file, line); // Skip header

    while (getline(file, line)) {
        vector<string> parts = split(line, delimiter);
        if (parts.size() >= 2 && parts[0] == email) {
            return true;
        }
    }
    return false;
}

bool FileManager::addUser(const string& email, const string& passwordHash, const string& fingerprintSid, WINBIO_BIOMETRIC_SUBTYPE subFactor) {
    try {
        ofstream file(userFile, ios::app);
        if (!file.is_open()) {
            cerr << "Error: Could not open user file: " << userFile << endl;
            return false;
        }

        // Write CSV header if file is empty
        if (file.tellp() == 0) {
            file << "Email,PasswordHash,FingerprintSID,SubFactor,RegistrationTime\n";
        }

        // Check if fingerprint (SID + sub-factor) is already registered
        if (isFingerprintRegistered(fingerprintSid, subFactor)) {
            cerr << "Error: This fingerprint is already registered to another user." << endl;
            return false;
        }

        // Write data in CSV format
        file << escapeCsvField(email) << delimiter
            << escapeCsvField(passwordHash) << delimiter
            << escapeCsvField(fingerprintSid) << delimiter
            << subFactor << delimiter
            << time(nullptr) << "\n";
        file.close();
        return true;
    }
    catch (const ios_base::failure& e) {
        cerr << "File I/O error: " << e.what() << endl;
        return false;
    }
    catch (const exception& e) {
        cerr << "General error: " << e.what() << endl;
        return false;
    }
}

bool FileManager::isFingerprintRegistered(const string& fingerprintSid, WINBIO_BIOMETRIC_SUBTYPE subFactor) {
    ifstream file(userFile);
    string line;
    getline(file, line); // Skip header

    while (getline(file, line)) {
        vector<string> parts = split(line, delimiter);
        if (parts.size() >= 4 && parts[2] == fingerprintSid && stol(parts[3]) == subFactor) {
            return true; // Fingerprint (SID + sub-factor) already exists
        }
    }
    return false;
}
string FileManager::getUserByFingerprint(const std::string& fingerprintSid, WINBIO_BIOMETRIC_SUBTYPE subFactor) {
    ifstream file(userFile);
    string line;
    getline(file, line); // Skip header

    while (getline(file, line)) {
        vector<string> parts = split(line, delimiter);
        if (parts.size() >= 4 && parts[2] == fingerprintSid && stoul(parts[3]) == subFactor) {
            file.close();
            return parts[0]; // Return the email associated with the fingerprint
        }
    }
    file.close();
    return "";
}

pair<string, WINBIO_BIOMETRIC_SUBTYPE> FileManager::getFingerprintData(const string& email) {
    ifstream file(userFile);
    string line;
    getline(file, line); // Skip header

    while (getline(file, line)) {
        vector<string> parts = split(line, delimiter);
        if (parts.size() >= 4 && parts[0] == email) {
            try {
                WINBIO_BIOMETRIC_SUBTYPE subFactor = static_cast<WINBIO_BIOMETRIC_SUBTYPE>(stoul(parts[3]));
                return { parts[2], subFactor };
            }
            catch (...) {
                cerr << "Error: Invalid sub-factor data for user: " << email << endl;
                return { "", 0 };
            }
        }
    }
    file.close();
    return { "", 0 };

}

bool FileManager::verifyPassword(const string& email, const string& passwordHash) {
    ifstream file(userFile);
    string line;
    getline(file, line); // Skip header

    while (getline(file, line)) {
        vector<string> parts = split(line, delimiter);
        if (parts.size() >= 2 && parts[0] == email) {
            if (parts[1] != passwordHash) {
                cerr << "Warning: Password mismatch for user " << email << endl;
                return false;
            }
            return true;
        }
    }
    return false;
}

bool FileManager::addResetToken(const string& email, const string& token, time_t expiresAt) {
    string encryptedToken = Utilities::encryptToken(token, email);
    if (encryptedToken.empty()) return false;

    // Remove any newlines from encrypted token
    encryptedToken.erase(remove(encryptedToken.begin(), encryptedToken.end(), '\n'), encryptedToken.end());

    ofstream file(tokenFile, ios::app);
    if (!file.is_open()) {
        cerr << "Error: Could not open token file: " << tokenFile << endl;
        return false;
    }

    if (file.tellp() > 0) {
        file << '\n';
    }

    file << email << '|' << encryptedToken << '|' << expiresAt << "|0";
    file.close();
    return true;
}

void FileManager::cleanTokenFile() {
    ifstream in(tokenFile);
    vector<string> validLines;
    string line;

    while (getline(in, line)) {
        vector<string> parts = split(line, '|');
        if (parts.size() == 4 && !parts[0].empty() && !parts[1].empty()) {
            validLines.push_back(line);
        }
    }
    in.close();

    ofstream out(tokenFile);
    for (const auto& valid : validLines) {
        out << valid << "\n";
    }
}

bool FileManager::verifyResetToken(const string& email, const string& token) {
    cleanTokenFile();
    ifstream file(tokenFile);
    if (!file.is_open()) {
        cerr << "Error: Could not open token file: " << tokenFile << endl;
        return false;
    }

    time_t now = time(nullptr);
    string line;
    while (getline(file, line)) {
        vector<string> parts = split(line, '|');
        if (parts.size() < 4 || parts[0] != email || parts[3] != "0") {
            continue;
        }

        try {
            time_t expiresAt = stol(parts[2]);
            if (expiresAt <= now) {
                continue;
            }

            string decryptedToken = Utilities::decryptToken(parts[1], email);
            if (decryptedToken == token) {
                return true;
            }
        }
        catch (...) {
            continue;
        }
    }
    return false;
}

bool FileManager::updatePassword(const string& email, const string& newPasswordHash) {
    ifstream inFile(userFile);
    vector<string> lines;
    string line;
    bool updated = false;

    getline(inFile, line); // Skip header
    lines.push_back(line);

    while (getline(inFile, line)) {
        vector<string> parts = split(line, delimiter);
        if (parts.size() >= 4 && parts[0] == email) {
            ostringstream oss;
            oss << escapeCsvField(email) << delimiter
                << escapeCsvField(newPasswordHash) << delimiter
                << escapeCsvField(parts[2]) << delimiter
                << parts[3] << delimiter
                << parts[4];
            line = oss.str();
            updated = true;
        }
        lines.push_back(line);
    }
    inFile.close();

    if (!updated) {
        cerr << "Error: User not found for email: " << email << endl;
        return false;
    }

    ofstream outFile(userFile);
    for (const auto& l : lines) {
        outFile << l << "\n";
    }

    ifstream inTokenFile(tokenFile);
    vector<string> tokenLines;

    while (getline(inTokenFile, line)) {
        vector<string> parts = split(line, '|');
        if (parts.size() >= 4 && parts[0] == email) {
            ostringstream oss;
            oss << parts[0] << '|' << parts[1] << '|' << parts[2] << "|1";
            line = oss.str();
        }
        tokenLines.push_back(line);
    }
    inTokenFile.close();

    ofstream outTokenFile(tokenFile);
    for (const auto& l : tokenLines) {
        outTokenFile << l << "\n";
    }

    return true;
}

bool FileManager::checkRateLimit(const string& email) {
    ifstream file(attemptFile);
    string line;
    time_t now = time(nullptr);
    int attempts = 0;

    while (getline(file, line)) {
        vector<string> parts = split(line, '|');
        if (parts.size() >= 3 && parts[0] == email) {
            time_t attemptTime = stol(parts[1]);
            if (difftime(now, attemptTime) < ATTEMPT_WINDOW) {
                attempts++;
            }
        }
    }
    file.close();

    //if (attempts >= MAX_ATTEMPTS) {
       // cerr << "Rate limit exceeded for email: " << email << endl;
     //   return false;
   // }

    ofstream outFile(attemptFile, ios::app);
    if (!outFile.is_open()) {
        cerr << "Error: Could not open attempt file: " << attemptFile << endl;
        return false;
    }
    outFile << email << '|' << now << '|' << "1\n";
    outFile.close();
    return true;
}