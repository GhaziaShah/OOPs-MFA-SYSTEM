#pragma once
#include "FileManager.h"
#include "AuthStrategy.h"
#include "Utilities.h"
#include "FingerPrintAuth.h"
class UserRegistration {
private:
    FileManager fm;
    string email;
    string username;
    string password;
    string fingerprintdata;
    AuthStrategy* authStrategy;

    bool isValidEmail(const string& email);
    static bool isStrongPassword(const string& password);
    bool isValidUsername(const string& username);

public:
    friend class PasswordAuth;
    void registerUser();
    bool loginWithFallback();
    void resetPasswordWithToken();
};
