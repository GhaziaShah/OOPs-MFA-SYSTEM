﻿

#include "FingerPrintAuth.h"
#include <iostream>


using namespace std;

bool FingerPrintAuth::identifyUser(WINBIO_IDENTITY& identity, WINBIO_BIOMETRIC_SUBTYPE& subFactor) {
    WINBIO_SESSION_HANDLE session = NULL;
    WINBIO_UNIT_ID unitId = 0;
    WINBIO_REJECT_DETAIL rejectDetail = 0;

    HRESULT hr = WinBioOpenSession(
        WINBIO_TYPE_FINGERPRINT,
        WINBIO_POOL_SYSTEM,
        0,
        NULL,
        0,
        WINBIO_DB_DEFAULT,
        &session);

    if (FAILED(hr)) {
        cerr << "WinBioOpenSession failed! HRESULT = 0x" << hex << hr << dec << endl;
        return false;
    }

    cout << endl;
    cout << "Place your finger on the scanner..." << endl;
    cout << endl;

    // Retry up to 3 times in case of no capture data
    for (int attempt = 1; attempt <= 3; ++attempt) {
        hr = WinBioIdentify(session, &unitId, &identity, &subFactor, &rejectDetail);
        if (SUCCEEDED(hr)) {
            break; // Success, exit loop
        }
        if (hr == WINBIO_E_NO_CAPTURE_DATA) {
            cerr << "Attempt " << attempt << ": No valid fingerprint data captured. Please ensure your finger is placed correctly and try again." << endl;
            if (attempt == 3) {
                cerr << "Failed to capture fingerprint after 3 attempts." << endl;
            }
            continue;
        }
        break; // Other errors stop immediately
    }

    if (FAILED(hr)) {
        cerr << "WinBioIdentify failed! HRESULT = 0x" << hex << hr << dec << endl;
        if (hr == WINBIO_E_NO_MATCH) {
            cerr << "No fingerprint match found." << endl;
        }
        else if (hr == WINBIO_E_BAD_CAPTURE) {
            cerr << "Bad fingerprint capture; please try again." << endl;
        }
        else if (hr == WINBIO_E_SENSOR_BUSY) {
            cerr << "Fingerprint sensor is busy. Try again later." << endl;
        }
        else if (hr == WINBIO_E_DEVICE_FAILURE) {
            cerr << "Fingerprint device failure." << endl;
        }
        else if (hr == WINBIO_E_NO_CAPTURE_DATA) {
            cerr << "No valid fingerprint data captured after multiple attempts." << endl;
        }
        else {
            cerr << "Unknown error during fingerprint identification." << endl;
        }
        WinBioCloseSession(session);
        return false;
    }

    cout << "Fingerprint matched on unit: " << unitId << endl;
    WinBioCloseSession(session);
    return true;
    /*/WINBIO_SESSION_HANDLE session = NULL;
    WINBIO_UNIT_ID unitId = 0;
    WINBIO_REJECT_DETAIL rejectDetail = 0;

    HRESULT hr = WinBioOpenSession(
        WINBIO_TYPE_FINGERPRINT,
        WINBIO_POOL_SYSTEM,
        0,
        NULL,
        0,
        WINBIO_DB_DEFAULT,
        &session);

    if (FAILED(hr)) {
        cerr << "WinBioOpenSession failed! HRESULT = 0x" << hex << hr << dec << endl;
        return false;
    }

    cout << endl;
    cout << "Place your finger on the scanner..." << endl;
    cout << endl;
    hr = WinBioIdentify(session, &unitId, &identity, &subFactor, &rejectDetail);

    if (FAILED(hr)) {
        cerr << "WinBioIdentify failed! HRESULT = 0x" << hex << hr << dec << endl;
        if (hr == WINBIO_E_NO_MATCH) {
            cerr << "No fingerprint match found." << endl;
        }
        else if (hr == WINBIO_E_BAD_CAPTURE) {
            cerr << "Bad fingerprint capture; please try again." << endl;
        }
        else if (hr == WINBIO_E_SENSOR_BUSY) {
            cerr << "Fingerprint sensor is busy. Try again later." << endl;
        }
        else if (hr == WINBIO_E_DEVICE_FAILURE) {
            cerr << "Fingerprint device failure." << endl;
        }
        else {
            cerr << "Unknown error during fingerprint identification." << endl;
        }
        WinBioCloseSession(session);
        return false;
    }

    cout << "Fingerprint matched on unit: " << unitId << endl;
    WinBioCloseSession(session);
    return true;*/
}

std::string FingerPrintAuth::identityToSidString(const WINBIO_IDENTITY& identity) {
    if (identity.Type != WINBIO_ID_TYPE_SID) {
        return "";
    }
    LPSTR sidString = NULL;
    if (!ConvertSidToStringSidA((PSID)identity.Value.AccountSid.Data, &sidString)) {
        return "";
    }
    string sidStr(sidString);
    LocalFree(sidString);
    return sidStr;
}

std::pair<std::string, WINBIO_BIOMETRIC_SUBTYPE> FingerPrintAuth::captureAndIdentify() {
    WINBIO_IDENTITY identity;
    WINBIO_BIOMETRIC_SUBTYPE subFactor = 0;
    if (!identifyUser(identity, subFactor)) {
        return { "", 0 };
    }
    string sidString = identityToSidString(identity);
    return { sidString, subFactor };
}

bool FingerPrintAuth::registerUser(const std::string& email, FileManager& fm) {
    /*/WINBIO_IDENTITY identity;
    WINBIO_BIOMETRIC_SUBTYPE subFactor = 0;

    if (!identifyUser(identity, subFactor)) {
        cerr << "Failed to capture fingerprint for registration." << endl;
        return false;
    }

    string sidString = identityToSidString(identity);
    if (sidString.empty()) {
        cerr << "Failed to convert SID to string." << endl;
        return false;
    }

    string existingEmail = fm.getUserByFingerprint(sidString, subFactor);
    if (!existingEmail.empty()) {
        cerr << "This fingerprint is already registered to another user (" << existingEmail << ")." << endl;
        return false;
    }
    */
    auto fingerprintData = captureAndIdentify();
    string sidString = fingerprintData.first;
    WINBIO_BIOMETRIC_SUBTYPE subFactor = fingerprintData.second; // Still captured but not used

    if (sidString.empty()) {
        cerr << "Failed to capture fingerprint for registration." << endl;
        return false;
    }
    // Note: The actual storage of user data (email, password, fingerprint) is handled by UserRegistration
    return true;
}

bool FingerPrintAuth::authenticate(const std::string& email, FileManager& fm) {
    auto fingerprintData = captureAndIdentify();
    string currentSidString = fingerprintData.first;
    WINBIO_BIOMETRIC_SUBTYPE currentSubFactor = fingerprintData.second; // Still captured but not used

    if (currentSidString.empty()) {
        cerr << "Failed to capture current fingerprint" << endl;
        return false;
    }

    pair<string, WINBIO_BIOMETRIC_SUBTYPE> storedData = fm.getFingerprintData(email);
    string storedSidString = storedData.first;
    WINBIO_BIOMETRIC_SUBTYPE storedSubFactor = storedData.second; // Still retrieved but not used

    if (storedSidString.empty()) {
        cerr << "No fingerprint data found for user: " << email << endl;
        return false;
    }

    auto trim = [](string& s) {
        s.erase(s.begin(), find_if(s.begin(), s.end(), [](unsigned char ch) { return !isspace(ch); }));
        s.erase(find_if(s.rbegin(), s.rend(), [](unsigned char ch) { return !isspace(ch); }).base(), s.end());
        };
    trim(currentSidString);
    trim(storedSidString);

    cout << "Debug: Captured SID: " << currentSidString << endl; // Removed SubFactor from debug
    cout << "Debug: Stored SID: " << storedSidString << endl;   // Removed SubFactor from debug

    bool match = (storedSidString == currentSidString); // Only compare SID
    if (!match) {
        cerr << "Fingerprint does not match stored data for user: " << email << endl;
    }
    else {
        cout << "Authentication successful for user: " << email << endl;
    }

    return match;
   /* auto fingerprintData = captureAndIdentify();
    string currentSidString = fingerprintData.first;
    WINBIO_BIOMETRIC_SUBTYPE currentSubFactor = fingerprintData.second;

    if (currentSidString.empty()) {
        cerr << "Failed to capture current fingerprint" << endl;
        return false;
    }

    pair<string, WINBIO_BIOMETRIC_SUBTYPE> storedData = fm.getFingerprintData(email);
    string storedSidString = storedData.first;
    WINBIO_BIOMETRIC_SUBTYPE storedSubFactor = storedData.second;

    if (storedSidString.empty()) {
        cerr << "No fingerprint data found for user: " << email << endl;
        return false;
    }

    // Debug output to compare values
    cout << "Debug: Captured SID: " << currentSidString << ", SubFactor: " << (int)currentSubFactor << endl;
    cout << "Debug: Stored SID: " << storedSidString << ", SubFactor: " << (int)storedSubFactor << endl;

    bool match = (storedSidString == currentSidString && storedSubFactor == currentSubFactor);
    if (!match) {
        cerr << "Fingerprint does not match stored data for user: " << email << endl;
    }
    else {
        cout << "Authentication successful for user: " << email << endl;
    }

    return match;
    */
}