#include "Utilities.h"


void Utilities::printHeader() {
    cout << R"(
/-------------------------------------------------------------------------------\
|                                                                               |
|  #     # #######   #        #####  #     #  #####  ####### ####### #     #    |
|  ##   ## #        # #      #     #  #   #  #     #    #    #       ##   ##    |
|  # # # # #       #   #     #         # #   #          #    #       # # # #    |
|  #  #  # #####  #     #     #####     #     #####     #    #####   #  #  #    |
|  #     # #      #######          #    #          #    #    #       #     #    |
|  #     # #      #     #    #     #    #    #     #    #    #       #     #    |
|  #     # #      #     #     #####     #     #####     #    ####### #     #    |
|                                                                               |
\-------------------------------------------------------------------------------/
)" << endl;
}

void Utilities::printSuccess(const string& message) {
    cout << "[SUCCESS] " << message << endl << endl;
}

void Utilities::printError(const string& message) {
    cout << "[ERROR] " << message << endl << endl;
}

void Utilities::printMenu() {
    cout << "\n=======================================================================================\n";
    cout << "                          WELCOME TO AUTHENTICATION SYSTEM      \n";
    cout << "=========================================================================================\n";
    cout << "1. Register\n";
    cout << "2. Login\n";
    cout << "3. Reset Password\n";
    cout << "4. Exit\n";
    cout << "=========================================================================================\n";
    cout << "Enter your choice: ";
}      // ===================== Utility Function Implementations =====================
string Utilities::encryptToken(const string& token, const string& email) {
    HCRYPTPROV hProv;
    HCRYPTKEY hKey;
    HCRYPTHASH hHash;

    // 1. Acquire crypto context
    if (!CryptAcquireContext(&hProv, NULL, MS_ENH_RSA_AES_PROV, PROV_RSA_AES, CRYPT_VERIFYCONTEXT)) {
        cerr << "CryptAcquireContext failed: " << GetLastError() << endl;
        return "";
    }

    // 2. Derive key from email (simplified example)
    if (!CryptCreateHash(hProv, CALG_SHA_256, 0, 0, &hHash)) {
        CryptReleaseContext(hProv, 0);
        cerr << "CryptCreateHash failed" << endl;
        return "";
    }

    if (!CryptHashData(hHash, (BYTE*)email.data(), (DWORD)email.size(), 0)) {
        CryptDestroyHash(hHash);
        CryptReleaseContext(hProv, 0);
        cerr << "CryptHashData failed" << endl;
        return "";
    }

    if (!CryptDeriveKey(hProv, CALG_AES_256, hHash, 0, &hKey)) {
        CryptDestroyHash(hHash);
        CryptReleaseContext(hProv, 0);
        cerr << "CryptDeriveKey failed" << endl;
        return "";
    }

    // 3. Encrypt the token
    DWORD dwLen = (DWORD)token.size();
    DWORD bufLen = dwLen + 16; // AES block size padding
    vector<BYTE> buf(bufLen);
    memcpy(buf.data(), token.data(), dwLen);


    if (!CryptEncrypt(hKey, NULL, TRUE, 0, buf.data(), &dwLen, (DWORD)buf.size())) {
        CryptDestroyKey(hKey);
        CryptDestroyHash(hHash);
        CryptReleaseContext(hProv, 0);
        cerr << "CryptEncrypt failed" << endl;
        return "";
    }

    // 4. Convert to Base64
    DWORD b64Len = 0;
    CryptBinaryToStringA(buf.data(), dwLen, CRYPT_STRING_BASE64, NULL, &b64Len);
    vector<char> b64(b64Len);
    CryptBinaryToStringA(buf.data(), dwLen, CRYPT_STRING_BASE64, b64.data(), &b64Len);

    // 5. Cleanup
    CryptDestroyKey(hKey);
    CryptDestroyHash(hHash);
    CryptReleaseContext(hProv, 0);

    return string(b64.data());
}

// Decrypts a Base64-encoded token
string Utilities::decryptToken(const string& encryptedToken, const string& email) {
    HCRYPTPROV hProv;
    HCRYPTKEY hKey;
    HCRYPTHASH hHash;

    // 1. Convert Base64 back to binary
    DWORD binLen = 0;
    CryptStringToBinaryA(encryptedToken.c_str(), (DWORD)encryptedToken.size(),
        CRYPT_STRING_BASE64, NULL, &binLen, NULL, NULL);
    vector<BYTE> buf(binLen);
    CryptStringToBinaryA(encryptedToken.c_str(), (DWORD)encryptedToken.size(),
        CRYPT_STRING_BASE64, buf.data(), &binLen, NULL, NULL);

    // 2. Recreate key (same as encryption)
    CryptAcquireContext(&hProv, NULL, MS_ENH_RSA_AES_PROV, PROV_RSA_AES, CRYPT_VERIFYCONTEXT);
    CryptCreateHash(hProv, CALG_SHA_256, 0, 0, &hHash);
    CryptHashData(hHash, (BYTE*)email.data(), (DWORD)email.size(), 0);
    CryptDeriveKey(hProv, CALG_AES_256, hHash, 0, &hKey);

    // 3. Decrypt
    DWORD dwLen = (DWORD)buf.size();
    if (!CryptDecrypt(hKey, NULL, TRUE, 0, buf.data(), &dwLen)) {
        CryptDestroyKey(hKey);
        CryptDestroyHash(hHash);
        CryptReleaseContext(hProv, 0);
        cerr << "CryptDecrypt failed" << endl;
        return "";
    }

    // 4. Cleanup
    CryptDestroyKey(hKey);
    CryptDestroyHash(hHash);
    CryptReleaseContext(hProv, 0);

    return string(buf.begin(), buf.begin() + dwLen);
}
string Utilities::hashPassword(const string& password) {
    HCRYPTPROV hProv;
    HCRYPTHASH hHash;
    BYTE rgbHash[20];
    DWORD cbHash = 20;
    CHAR rgbDigits[] = "0123456789abcdef";

    if (!CryptAcquireContext(&hProv, NULL, NULL, PROV_RSA_FULL, CRYPT_VERIFYCONTEXT)) {
        cerr << "Error acquiring context" << endl;
        return "";
    }

    if (!CryptCreateHash(hProv, CALG_SHA1, 0, 0, &hHash)) {
        cerr << "Error creating hash" << endl;
        CryptReleaseContext(hProv, 0);
        return "";
    }

    DWORD passwordLength = static_cast<DWORD>(password.length());

    if (!CryptHashData(hHash,
        reinterpret_cast<const BYTE*>(password.c_str()),
        passwordLength,
        0))
    {
        DWORD err = GetLastError();
        cerr << "Error hashing data (Error Code: 0x" << hex << err << ")" << endl;
        CryptDestroyHash(hHash);
        CryptReleaseContext(hProv, 0);
        return "";
    }
    if (!CryptGetHashParam(hHash, HP_HASHVAL, rgbHash, &cbHash, 0)) {
        cerr << "Error getting hash param" << endl;
        CryptDestroyHash(hHash);
        CryptReleaseContext(hProv, 0);
        return "";
    }

    ostringstream oss;
    for (DWORD i = 0; i < cbHash; i++) {
        oss << hex << setw(2) << setfill('0') << (int)rgbHash[i];
    }

    CryptDestroyHash(hHash);
    CryptReleaseContext(hProv, 0);

    return oss.str();
}