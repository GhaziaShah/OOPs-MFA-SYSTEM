#include <iostream>
#include <string>
#include <ctime>
#include <windows.h>
#include <wincrypt.h>
#include <sstream>
#include <iomanip>
#include <map>
#include <curl/curl.h>
#include <winbio.h>
#include <fstream>
#include <vector>
#include <algorithm>
#include <sddl.h>         
#pragma comment(lib, "Crypt32.lib")
#ifndef WINBIO_E_SENSOR_BUSY
#define WINBIO_E_SENSOR_BUSY 0x80098005L
#endif
#pragma comment(lib, "advapi32.lib")
#pragma comment(lib, "winbio.lib")
#pragma comment(lib, "libcurl.lib")
using namespace std;

#pragma once


class Utilities {
public:
    static void printHeader();
    static void printSuccess(const string& message);
    static void printError(const string& message);
    static void printMenu();
    static std::string encryptToken(const string& token, const string& key);
    static std::string decryptToken(const string& token, const string& key);
    static std::string hashPassword(const string& password);
};