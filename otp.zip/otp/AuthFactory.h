#pragma once
#include "AuthStrategy.h"
class AuthFactory {
public:
    static AuthStrategy* createAuthStrategy(const string& type);
};