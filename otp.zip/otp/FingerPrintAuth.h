#pragma once
#include "AuthStrategy.h"
#include <windows.h>
#include <winbio.h>
#ifndef WINBIO_E_SENSOR_BUSY
#include <sddl.h>
#include "FileManager.h"
#include <string>
#include "Utilities.h"
#endif

class FingerPrintAuth : public AuthStrategy {
public:
    FingerPrintAuth() {}
    bool authenticate(const std::string& email, FileManager& fm);
    bool registerUser(const std::string& email, FileManager& fm); // Added
    pair<string, WINBIO_BIOMETRIC_SUBTYPE> captureAndIdentify(); // Updated to return both SID and sub-factor

private:
    bool identifyUser(WINBIO_IDENTITY& identity, WINBIO_BIOMETRIC_SUBTYPE& subFactor);
    string identityToSidString(const WINBIO_IDENTITY& identity);
};
