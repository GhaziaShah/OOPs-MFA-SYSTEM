﻿
#include "PasswordAuth.h"

    string PasswordAuth::generateRandomToken() {
        const string chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
        string token;
        for (int i = 0; i < 32; ++i) {
            token += chars[rand() % chars.length()];
        }
        return token;
    }

    bool PasswordAuth::initiatePasswordReset(const string& email, FileManager& fm) {

        string token = generateRandomToken();
        time_t expiration = time(nullptr) + 600; // 10 minutes expiration

        if (!fm.addResetToken(email, token, expiration)) {
            cerr << "Failed to store reset token" << endl;
            return false;
        }

        if (!sendResetEmail(email, token)) {
            cerr << "Failed to send reset email" << endl;
            return false;
        }

        cout << "Password reset link sent to your email. Please check your inbox." << endl;
        return true;
    }


    size_t PasswordAuth::payload_source(void* ptr, size_t size, size_t nmemb, void* userp) {
        string* data = (string*)userp;
        if (size * nmemb < 1) return 0;
        if (data->empty()) return 0;

        size_t len = data->copy((char*)ptr, size * nmemb);
        data->erase(0, len);
        return len;
    }

    bool PasswordAuth::sendResetEmail(const string& email, const string& token) {
        CURL* curl;
        CURLcode res = CURLE_OK;
        bool success = false;



        string resetLink = "https://yourapp.com/reset?token=" + token;
        string from = "ghaziabatool260@gmail.com";
        string to = email;
        string payload_text = "To: " + to + "\r\n" +
            "From: " + from + "\r\n" +
            "Subject: Password Reset Request\r\n\r\n" +
            "The below link contains your password reset token: " + resetLink + "\r\n" +
            "This link will expire in 10 minutes.\r\n";

        curl = curl_easy_init();
        if (curl) {
            curl_easy_setopt(curl, CURLOPT_USERNAME, "ghaziabatool260@gmail.com");
            curl_easy_setopt(curl, CURLOPT_PASSWORD, "pdrswcpmscctyvgt");
            curl_easy_setopt(curl, CURLOPT_URL, "smtps://smtp.gmail.com:465");
            curl_easy_setopt(curl, CURLOPT_USE_SSL, CURLUSESSL_ALL);
            curl_easy_setopt(curl, CURLOPT_MAIL_FROM, from.c_str());

            struct curl_slist* recipients = NULL;
            recipients = curl_slist_append(recipients, to.c_str());
            curl_easy_setopt(curl, CURLOPT_MAIL_RCPT, recipients);

            curl_easy_setopt(curl, CURLOPT_READFUNCTION, payload_source);
            curl_easy_setopt(curl, CURLOPT_READDATA, &payload_text);
            curl_easy_setopt(curl, CURLOPT_UPLOAD, 1L);
            curl_easy_setopt(curl, CURLOPT_VERBOSE, 1L);

            res = curl_easy_perform(curl);
            if (res != CURLE_OK) {
                cerr << "curl_easy_perform() failed: " << curl_easy_strerror(res) << endl;
            }
            else {
                success = true;
            }

            curl_slist_free_all(recipients);
            curl_easy_cleanup(curl);
        }
        return success;
    }

    bool PasswordAuth::authenticate(const string& email, FileManager& fm){
        string password;
        cout << "Enter password: ";
        cin >> password;

        string hashedPassword = Utilities::hashPassword(password);
        if (fm.verifyPassword(email, hashedPassword)) {
            return true;
        }

        cout << "Incorrect password. Forgot password? [Y] [N] ";
        char choice;
        cin >> choice;
        if (choice == 'y' || choice == 'Y') {

            if (PasswordAuth::initiatePasswordReset(email, fm)) {
                string enteredToken;
                cout << "Enter the reset token: ";
                cin >> enteredToken;

                if (fm.verifyResetToken(email, enteredToken)) {
                    string newPassword;
                    do{
                    cout << "Enter password (8-16 chars, mix of upper/lower/digits): ";
                    getline(cin, newPassword);
                    if (!UserRegistration::isStrongPassword(password)) {
                        Utilities::printError("Password must be 8-16 characters with uppercase, lowercase, and numbers");
                    }
                    else {
                        break;
                    }
                    } while (true);

                     string newHashedPassword = Utilities::hashPassword(newPassword);
                     if (fm.updatePassword(email, newHashedPassword)) {
                         cout << "Password has been reset successfully. Please log in again." << endl;
                         return false;
                     }
                 }

                 else {
                     cerr << "Failed to initiate password reset" << endl;
                 }
             }
             else {
                 cerr << "Invalid or expired reset token." << endl;
             }
         }
         return false;
     }