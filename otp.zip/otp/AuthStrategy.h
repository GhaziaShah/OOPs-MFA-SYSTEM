#pragma once
#include "FileManager.h"
#include <iostream>
#include <string>
#include <ctime>
#include <windows.h>
#include <wincrypt.h>
#include <sstream>
#include <iomanip>
#include <map>
#include <curl/curl.h>
#include <winbio.h>
#include <fstream>
#include <vector>
#include <algorithm>
#include <sddl.h>         
#pragma comment(lib, "Crypt32.lib")
#ifndef WINBIO_E_SENSOR_BUSY
#define WINBIO_E_SENSOR_BUSY 0x80098005L
#endif
#pragma comment(lib, "advapi32.lib")
#pragma comment(lib, "winbio.lib")
#pragma comment(lib, "libcurl.lib")
using namespace std;
class AuthStrategy {
public:
    virtual bool authenticate(const string& email, FileManager& fm) = 0;
    virtual ~AuthStrategy() {}
};

