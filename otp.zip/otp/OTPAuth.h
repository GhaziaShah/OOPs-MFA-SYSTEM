#pragma once
#include "AuthStrategy.h"
class OTPAuth : public AuthStrategy {
private:
    map<string, pair<string, time_t>> otpStorage;
    string generateOTP();
    static size_t payload_source(void* ptr, size_t size, size_t nmemb, void* userp);
    bool sendOTPEmail(const string& email, const string& otp);

public:
    bool authenticate(const string& email, FileManager& fm) override;
};