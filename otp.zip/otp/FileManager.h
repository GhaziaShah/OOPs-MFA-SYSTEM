/*/#pragma once
#include <iostream>
#include <string>
#include <vector>
#include <sstream>
#include <fstream>
using namespace std;

class FileManager {
private:
    const string userFile;
    const string tokenFile;
    const char delimiter;
    const string attemptFile;
    const int MAX_ATTEMPTS;
    const int ATTEMPT_WINDOW;

    vector<string> split(const string& s, char delim);
    string escapeCsvField(const string& field);

public:
    FileManager():
        userFile("users.csv"),
        tokenFile("tokens.txt"),
        delimiter(','),
        attemptFile("attempts.txt"),
        MAX_ATTEMPTS(5),
        ATTEMPT_WINDOW(3600) {
    }
    bool verifyToken(const string& token);
    //string getEmailForToken(const string& token);
    //void removeToken(const string& token);
    bool isEmailRegistered(const string& email);
    bool addUser(const string& username, const string& email,
    const string& passwordHash, const string& fingerprint);
    bool verifyPassword(const string& email, const string& passwordHash);
    bool addResetToken(const string& email, const string& token, time_t expiresAt);
    void cleanTokenFile();
    bool verifyResetToken(const string& email, const string& token);
    bool updatePassword(const string& username,const string& email, const string& newPasswordHash);
    string getFingerprintData(const string& email);
    bool checkRateLimit(const string& email);
};*/


/*/class FileManager {
private:
    const string userFile;
    const string tokenFile;
    const char delimiter;
    const string attemptFile;
    const int MAX_ATTEMPTS;
    const int ATTEMPT_WINDOW;

    vector<string> split(const string& s, char delim);
    string escapeCsvField(const string& field);

public:
    //FileManager();
    FileManager()
        : userFile("users.csv"),
        tokenFile("tokens.txt"),
        delimiter(','),
        attemptFile("attempts.txt"),
        MAX_ATTEMPTS(5),
        ATTEMPT_WINDOW(3600) {
    }
    bool verifyToken(const string& token);
    string getEmailForToken(const string& token);
    void removeToken(const string& token);
    bool isEmailRegistered(const string& email);
    bool addUser(const string& email, const string& passwordHash, const string& fingerprint,const std::string& fingerprintSid);
    bool isFingerprintRegistered(const string& fingerprintSid);
    bool verifyPassword(const string& email, const string& passwordHash);
    bool addResetToken(const string& email, const string& token, time_t expiresAt);
    bool verifyResetToken(const string& email, const string& token);
    bool updatePassword(const string& email, const string& newPasswordHash);
    string getFingerprintData(const string& email);
    bool checkRateLimit(const string& email);
};*/
#pragma once
#include <string>
#include <vector>
#include <sstream>
#include "Utilities.h"
#include <fstream>
using namespace std;
#include <winbio.h>

class FileManager {
public:
    FileManager();
    bool isEmailRegistered(const std::string& email);
    bool addUser(const string& email, const string& passwordHash, const string& fingerprintSid, WINBIO_BIOMETRIC_SUBTYPE subFactor);
    bool isFingerprintRegistered(const std::string& fingerprintSid, WINBIO_BIOMETRIC_SUBTYPE subFactor);
    std::string getUserByFingerprint(const std::string& fingerprintSid, WINBIO_BIOMETRIC_SUBTYPE subFactor);
    std::pair<std::string, WINBIO_BIOMETRIC_SUBTYPE> getFingerprintData(const std::string& email);
    bool verifyPassword(const std::string& email, const std::string& passwordHash);
    bool addResetToken(const std::string& email, const std::string& token, time_t expiresAt);
    bool verifyResetToken(const std::string& email, const std::string& token);
    bool updatePassword(const std::string& email, const std::string& newPasswordHash);
    bool verifyToken(const std::string& token);
    std::string getEmailForToken(const std::string& token);
    void removeToken(const std::string& token);
    bool checkRateLimit(const std::string& email);
    void cleanTokenFile();

private:
    std::vector<std::string> split(const std::string& s, char delim);
    std::string escapeCsvField(const std::string& field);
    const char delimiter = ',';
    const std::string userFile = "users.csv";
    const std::string tokenFile = "tokens.txt";
    const std::string attemptFile = "attempts.txt";
    const int MAX_ATTEMPTS = 5;
    const int ATTEMPT_WINDOW = 3600; 
};
