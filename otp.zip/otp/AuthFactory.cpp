#include "AuthFactory.h"
#include "PasswordAuth.h"
#include "FingerPrintAuth.h"
#include "OTPAuth.h"
AuthStrategy* AuthFactory::createAuthStrategy(const string& type) {
    if (type == "password") return new PasswordAuth();
    if (type == "otp") return new OTPAuth();
    if (type == "fingerprint") return new FingerPrintAuth();
    return nullptr;
}