#pragma once
#include "AuthStrategy.h"
#include "Utilities.h"
#include "UserRegistration.h"
class PasswordAuth : public AuthStrategy {
private:
    string generateRandomToken();
    bool initiatePasswordReset(const string& email, FileManager& fm);
    static size_t payload_source(void* ptr, size_t size, size_t nmemb, void* userp);
    bool sendResetEmail(const string& email, const string& token);

public:
    friend class UserRegistration;
    bool authenticate(const string& email, FileManager& fm) override;
};