
#include "FingerPrintAuth.h"
#include "Utilities.h"
#include "OTPAuth.h"
#include "PasswordAuth.h"
#include "UserRegistration.h"
#include "AuthFactory.h"

   
void UserRegistration::registerUser() {
    cout << "\n=== REGISTRATION ===\n";
    string username;
    cin.ignore(10000, '\n');
    do {
        cout << "Enter a Username. Use only letters, underscores (_), or hyphens (-).(Max 30 characters and minimum 10)" << endl;
        getline(cin, username);
        if (!isValidUsername(username)) {
            Utilities::printError("Invalid username. Use only letters, underscores (_), or hyphens (-)(Max 30 characters and minimum 10).");
            cout << endl;
        }
        else {
            break;
        }
    } while (true);

    do {
        cout << "Enter email: ";
        getline(cin, email);
        if (!isValidEmail(email)) {
            Utilities::printError("Invalid email format. Must contain @ and ., with proper domain structure");
        }
        else if (fm.isEmailRegistered(email)) {
            Utilities::printError("Email already registered");
        }
        else {
            break;
        }
    } while (true);

    string password;
    do {
        cout << "Enter password (8-16 chars, mix of upper/lower/digits): ";
        getline(cin, password);
        if (!isStrongPassword(password)) {
            Utilities::printError("Password must be 8-16 characters with uppercase, lowercase, and numbers");
        }
        else {
            break;
        }
    } while (true);

    FingerPrintAuth fpAuth;
    auto fingerprintData = fpAuth.captureAndIdentify();
    string sidString = fingerprintData.first;
    WINBIO_BIOMETRIC_SUBTYPE subFactor = fingerprintData.second;

    if (sidString.empty()) {
        Utilities::printError("Failed to capture fingerprint. Please ensure the scanner is clean and your finger is placed correctly.");
        return;
    }

    if (!fpAuth.registerUser(email, fm)) {
        Utilities::printError("Fingerprint registration failed. It may already be in use or the capture failed.");
        return;
    }

    cout << "Debug: Attempting to add user - Email: " << email << ", SID: " << sidString << endl;
    if (fm.addUser(email, Utilities::hashPassword(password), sidString, subFactor)) {
        Utilities::printSuccess("Registration successful!");
    }
    else {
        Utilities::printError("Registration failed. Check file permissions or data.");
    }
}
bool UserRegistration::loginWithFallback() {

    cout << "\n=== LOGIN ===\n";
    cout << "Enter email: ";
    cin >> email;

    if (!fm.isEmailRegistered(email)) {
        Utilities::printError("Email not registered");
        return false;
    }
    if (!fm.checkRateLimit(email)) {
        Utilities::printError("Too many attempts. Please try again later.");
        return false;
    }

    cout << "\nAttempting fingerprint authentication...\n";
    FingerPrintAuth fpAuth;
    if (fpAuth.authenticate(email, fm)) {
        cout << "Fingerprint authentication successful!" << endl;
        return true;
    }

    cout << "Fingerprint authentication failed. Trying password..." << endl;

    PasswordAuth pwAuth;
    if (pwAuth.authenticate(email, fm)) {
        cout << "Password authentication successful!" << endl;
        return true;
    }

    cout << "Password authentication failed. Trying OTP generation..." << endl;

    OTPAuth otpAuth;
    if (otpAuth.authenticate(email, fm)) {
        cout << "OTP authentication successful!" << endl;
        return true;
    }

    cout << "All authentication methods failed." << endl;
    return false;

    if (!fm.checkRateLimit(email)) {
        Utilities::printError("Too many attempts. Please try again later.");
        return false;
    }

}
void UserRegistration::resetPasswordWithToken() {
    cout << "\n=== PASSWORD RESET ===\n";
    string email, token, newPassword;
    cout << "Enter your email: ";
    cin >> email;

    if (!fm.isEmailRegistered(email)) {  // <-- Check registration first
        Utilities::printError("Email not registered. Cannot reset password.");
        return;
    }

    PasswordAuth pwAuth;
    if (pwAuth.initiatePasswordReset(email, fm)) {
        string token, newPassword;
        cout << "Enter the reset token: ";
        cin >> token;

        if (!fm.verifyResetToken(email, token)) {
            Utilities::printError("Invalid or expired token");
            return;
        }

        cout << "Enter new password: ";
        cin >> newPassword;

        if (fm.updatePassword(email, Utilities::hashPassword(newPassword))) {
            Utilities::printSuccess("Password reset successfully!");
        }
        else {
            Utilities::printError("Password reset failed");
        }
    }
    else {
        Utilities::printError("Failed to initiate password reset");
    }
}
bool UserRegistration::isValidEmail(const string& email) {
    // Must contain @ and .
    if (email.find('@') == string::npos || email.find('.') == string::npos) {
        return false;
    }

    // Check for proper domain structure (at least one character before @,
    // at least one character between @ and ., and at least two characters after .)
    size_t at_pos = email.find('@');
    size_t dot_pos = email.rfind('.');

    if (at_pos == 0 || dot_pos - at_pos <= 1 || email.length() - dot_pos <= 2) {
        return false;
    }

    // Only allowed special characters
    const string allowed_special_chars = "._%+-";
    for (char c : email) {
        if (!isalnum(c) && allowed_special_chars.find(c) == string::npos && c != '@' && c != '.') {
            return false;
        }
    }

    return true;
}
bool UserRegistration::isStrongPassword(const string& password) {
    // Length check
    if (password.length() < 8 || password.length() > 16) {
        return false;
    }

    bool hasUpper = false;
    bool hasLower = false;
    bool hasDigit = false;
    for (char c : password) {
        if (isupper(c)) hasUpper = true;
        if (islower(c)) hasLower = true;
        if (isdigit(c)) hasDigit = true;
    }

    if (!hasUpper || !hasLower || !hasDigit) {
        return false;
    }

    string lowerPass = password;
    transform(lowerPass.begin(), lowerPass.end(), lowerPass.begin(), ::tolower);

    return true;
}
bool UserRegistration::isValidUsername(const string& username) {
    if (username.empty() || username.length() < 10 || username.length() > 30) {
        return false;
    }
    for (char c : username) {
        if (!isalpha(c) && c != ' ' && c != '_' && c != '-') {

            return false;
        }
    }
    return true;
}